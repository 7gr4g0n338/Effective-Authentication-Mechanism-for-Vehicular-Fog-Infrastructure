package org.bouncycastle.util;

public class Shorts
{
    public static Short valueOf(short value)
    {
        return new Short(value);
    }
}
